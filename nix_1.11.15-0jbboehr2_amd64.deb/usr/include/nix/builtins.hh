#pragma once

#include "derivations.hh"

namespace nix {

void builtinFetchurl(const BasicDerivation & drv);

}
