#pragma once

#include <string>

namespace nix {

std::string decompressXZ(const std::string & in);

}
